DROP TABLE IF EXISTS #__virtualdomain;
DROP TABLE IF EXISTS #__virtualdomain_params;