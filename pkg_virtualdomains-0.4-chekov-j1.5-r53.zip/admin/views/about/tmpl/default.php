<?php
defined('_JEXEC') or die( 'Restricted access' );
	JToolBarHelper::title(   JText::_( 'About' ), 'generic.png' );
	JToolBarHelper::help( 'virtualdomain', 1 ); 
?>
<fieldset class="adminform">
<legend>About</legend>
<table class="admintable" width="100%">
  <tbody>
  <tr class="row0">
    <td class="key">Author</td>
    <td>Michael Liebler</td>
  </tr>
  <tr class="row1">
    <td class="key">Website</td>
    <td><a href="http://www.janguo.de">www.janguo.de</a></td>
  </tr>
  <tr>
    <td class="key">Support Forum</td>
    <td><a href="http://forum.janguo.de">forum.janguo.de</a></td>
  </tr>  
  </tbody>
</table>
</fieldset>