<?php
defined('_JEXEC') or die( 'Restricted access' );
	JToolBarHelper::title(   JText::_( 'About' ), 'generic.png' );
	 VirtualdomainsHelper::helpIcon('About');
?>
<fieldset class="adminform">
<legend>About</legend>
<table class="admintable" width="100%">
  <tbody>
  <tr class="row0">
    <td class="key">Authors</td>
    <td><a href="http://janguo.de">Michael Liebler</a>, <a href="http://romacron.de">Roman Teske</a></td>
  </tr>
  <tr class="row1">
    <td class="key">Project Website</td>
    <td><a href="http://redmine.janguo.de/projects/vd-main">redmine.janguo.de</a></td>
  </tr>
  <tr>
    <td class="key">Support Forum</td>
    <td><a href="http://forum.janguo.de">forum.janguo.de</a></td>
  </tr>
<tr>
    <td class="key">Wiki</td>
    <td><a href="http://redmine.janguo.de/projects/vd-main/wiki">Wiki</a></td>
  </tr>      
  </tbody>
</table>
</fieldset>